package Excepciones;

/**
 * @author Jaime Mendoza
 */
public class Llena extends Exception{

    public Llena() {
        super("La empresa ya esta LLENA");
    }

    public Llena (String string) {
        super(string);
    }
    
}
