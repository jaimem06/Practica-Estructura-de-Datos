package Excepciones;

/**
 * @author Jaime Mendoza
 */
public class Vacia extends Exception {

    public Vacia() {
        super("La empresa esta VACIA");
    }

    public Vacia(String string) {
        super(string);
    }

}
