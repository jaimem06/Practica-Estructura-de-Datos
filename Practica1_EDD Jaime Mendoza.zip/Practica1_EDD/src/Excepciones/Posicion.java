package Excepciones;

/**
 * @author Jaime Mendoza
 */
public class Posicion extends Exception {

    public Posicion() {
        System.out.println("La posicion es INVALIDA");
    }

    public Posicion(String string) {
        super(string);
    }

}
