package Modelo;

/**
 * @author Jaime Mendoza
 */

    public enum Categoria {
        Veterano, Senior, Junior;
    }


