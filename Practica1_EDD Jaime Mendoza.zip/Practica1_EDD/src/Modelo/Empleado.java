package Modelo;

import java.util.Calendar;

public class Empleado {

    private Calendar ingresoEmpleado;
    private Integer id, tiempoEmpl;
    private String nombres, apellidos;
    private Float sueldo, bonificacion, sueldoEmpl;
    private Categoria categoria;
    private Boolean pagado;
    
    public Empleado() {
    }

    public Empleado(String nombres, String apellidos, Float sueldo, Calendar ingresoEmpleado) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.sueldo = sueldo;
        this.ingresoEmpleado = ingresoEmpleado;
    }

    public Boolean getPagado() {
        return pagado;
    }

    public void setPagado(Boolean pagado) {
        this.pagado = pagado;
    }

    public Float getSueldoEmpl() {
        return sueldoEmpl;
    }

    public void setSueldoEmpl(Float sueldoEmpl) {
        this.sueldoEmpl = sueldoEmpl;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Float getSueldo() {
        return sueldo;
    }

    public void setSueldo(Float sueldo) {
        this.sueldo = sueldo;
    }

    public Integer getTiempoEmpl() {
        return tiempoEmpl;
    }

    public void setTiempoEmpl(Integer tiempoEmpl) {
        this.tiempoEmpl = tiempoEmpl;
    }

    public Calendar getIngresoEmpleado() {
        return ingresoEmpleado;
    }

    public void setIngresoEmpleado(Calendar ingresoEmpleado) {
        this.ingresoEmpleado = ingresoEmpleado;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Float getBono() {
        return bonificacion;
    }

    public void setBono(Float bono) {
        this.bonificacion = bono;
    }

    public String mostrarFechaEmpl() {
        String cadena;
        cadena = "" + ingresoEmpleado.get(Calendar.YEAR) + "    " + ingresoEmpleado.get(Calendar.MONTH) +
        "   " + ingresoEmpleado.get(Calendar.DATE);
        return cadena;
    }

    @Override
    public String toString() {
        return "Empleado{" + "Identificador="
                + id + ", nombres=" + nombres
                + ", apellidos=" + apellidos + ", sueldo="
                + sueldo + ", aniosEmpleo=" + tiempoEmpl
                + ", fechaIngreso=" + mostrarFechaEmpl()
                + ", rango=" + categoria + ", bono="
                + bonificacion + '}';
    }

}
