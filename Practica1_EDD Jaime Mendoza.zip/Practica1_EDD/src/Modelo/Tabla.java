package Modelo;

import javax.swing.table.AbstractTableModel;

/**
 * @author Jaime Mendoza
 */
public class Tabla extends AbstractTableModel {

    private Empleado[] Empleados;

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public int getRowCount() {
        return Empleados.length;
    }

    @Override
    public String getColumnName(int column) {
        switch (column)
        {
            case 0:
                return "Identicador";
            case 1:
                return "Nombres";
            case 2:
                return "Categoria";
            case 3:
                return "Salario";
            case 4:
                return "Bonificacion";
            case 5:
                return "Sueldo Total";
            case 6:
                return "Estado";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Empleado t = Empleados[rowIndex];
        switch (columnIndex)
        {
            case 0:
                return (rowIndex + 1);
            case 1:
                return (t != null) ? t.getNombres() + " " + t.getApellidos() : " ";
            case 2:
                return (t != null) ? t.getCategoria() : " ";
            case 3:
                return (t != null) ? t.getSueldo() : " ";
            case 4:
                return (t != null) ? (t.getBono() * 100) + "%" : " ";
            case 5:
                return (t != null) ? t.getSueldoEmpl(): " ";
            case 6:
                return (t != null) ? t.getPagado() : " ";
            default:
                return null;
        }
    }

    public Empleado[] getEmpleados() {
        return Empleados;
    }

    public void setEmpleados(Empleado[] Empleados) {
        this.Empleados = Empleados;
    }

}
