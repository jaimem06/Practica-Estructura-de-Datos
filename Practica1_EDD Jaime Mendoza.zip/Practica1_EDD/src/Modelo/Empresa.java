package Modelo;

/**
 * @author Jaime Mendoza
 */
public class Empresa {

    private Integer ID;
    private String nombre;
    private Empleado[] ArregloEmpleado;

    public Empresa() {
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Empleado [] getArregloEmpleado() {
        return ArregloEmpleado;
    }

    public void setArregloEmpleado(Empleado[] ArregloEmpleado) {
        this.ArregloEmpleado = ArregloEmpleado;
    }

}