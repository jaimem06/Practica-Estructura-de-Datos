package Vista;

import Controlador.Controlador;
import Controlador.Controlador_Guardar;
import Excepciones.Llena;
import Modelo.Empleado;
import Modelo.Tabla;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Jaime Mendoza
 */
public class Interfaz extends javax.swing.JFrame {

    private Controlador ControllerE = new Controlador();
    private Tabla mtabla = new Tabla();

    public Interfaz() {

        initComponents();

        //Centrar la interfaz
        this.setLocationRelativeTo(null);
    }
    public void CargarArchivo() {
        try
        {

            this.ControllerE = Controlador_Guardar.Leer_Datos();
            llenarT();
        } catch (IOException ex)
        {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void limpiarTabla() {
        txtAnio.setText(" ");
        txtMes.setText(" ");
        txtDia.setText(" ");
        txtNombre.setText(" ");
        txtApellido.setText(" ");
        txtSalario.setText(" ");
    }

    public void Empresa_Tabla() {
        if (!txt_nombEmpresa.getText().isEmpty())
        {
            ControllerE = new Controlador(txt_nombEmpresa.getText(), Integer.parseInt(cantEmpleados.getValue().toString()));
            llenarT();
            JOptionPane.showMessageDialog(null, "Guardado");
        } else
        {
            JOptionPane.showMessageDialog(null, "Ingrese el nombre de la empresa");
        }
    }
    
    
    public void llenarT() {
        if (ControllerE.getEmpresa().getArregloEmpleado() != null)
        {
            mtabla.setEmpleados(ControllerE.getEmpresa().getArregloEmpleado());
            jTable1.setModel(mtabla);
            jTable1.updateUI();
        } else
        {
            JOptionPane.showMessageDialog(null, "Nombre Empresa no ingresado");
        }

    }

    public void guardarEmpleado() throws Llena {
        if (txtNombre.getText().isEmpty() || txtApellido.getText().isEmpty()
                || txtSalario.getText().isEmpty() || txtAnio.getText().isEmpty()
                || txtDia.getText().isEmpty() || txtMes.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "DATOS INCOMPLETOS");
        } else
        {
            Calendar calendaio = Calendar.getInstance();
            calendaio.set(Integer.parseInt(txtAnio.getText()), Integer.parseInt(txtMes.getText()), Integer.parseInt(txtDia.getText()));
            Empleado G_empleado = new Empleado(txtNombre.getText(), txtApellido.getText(), Float.parseFloat(txtSalario.getText()), calendaio);
            G_empleado.setTiempoEmpl(Controlador_Guardar.CalcularTiempoTrabajando(calendaio));
            G_empleado.setCategoria(Controlador_Guardar.Asignar_Categoria(G_empleado));
            G_empleado.setBono(Controlador_Guardar.Asignar_Bonificacion(G_empleado.getCategoria()));
            G_empleado.setSueldo(Controlador_Guardar.CalcularSalario(G_empleado));
            G_empleado.setPagado(false);
            limpiarTabla();
            llenarT();
            JOptionPane.showMessageDialog(null, "Datos Guardados");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnGuardarE = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txt_nombEmpresa = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cantEmpleados = new javax.swing.JSpinner();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtDia = new javax.swing.JTextField();
        txtMes = new javax.swing.JTextField();
        txtAnio = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtSalario = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btnGuardarEmpleado = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TablaDatos = new javax.swing.JTable();
        btnCargarDatos = new javax.swing.JButton();
        btnguardarJson = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnGuardarE.setText("GUARDAR");
        btnGuardarE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarEActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardarE, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 100, -1));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Ingrese el nombre de la empresa:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        txt_nombEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombEmpresaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_nombEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 220, -1));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Ingrese la cantidad de Empleados:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));
        getContentPane().add(cantEmpleados, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 80, -1));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Cantarell", 1, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("REGISTRAR EMPLEADO");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 10, -1, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Ingrese la fecha:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 40, -1, -1));
        getContentPane().add(txtDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, 40, -1));
        getContentPane().add(txtMes, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 40, 40, -1));

        txtAnio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAnioActionPerformed(evt);
            }
        });
        getContentPane().add(txtAnio, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 40, 70, -1));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Dia");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 70, -1, -1));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Mes");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 70, -1, -1));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Año");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 70, -1, -1));

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Nombre Empleado:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 100, -1, -1));

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Apellido Empleado:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, -1, -1));

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 100, 180, -1));
        getContentPane().add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 150, 180, -1));

        txtSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalarioActionPerformed(evt);
            }
        });
        getContentPane().add(txtSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 200, 90, -1));

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Salario Empleado:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, -1, -1));

        btnGuardarEmpleado.setText("Guardar Datos");
        btnGuardarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarEmpleadoActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardarEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 250, -1, -1));

        TablaDatos.setBackground(new java.awt.Color(153, 255, 255));
        TablaDatos.setForeground(new java.awt.Color(0, 0, 0));
        TablaDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(TablaDatos);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 307, 590, 160));

        btnCargarDatos.setBackground(new java.awt.Color(255, 102, 102));
        btnCargarDatos.setForeground(new java.awt.Color(0, 0, 0));
        btnCargarDatos.setText("Cargar Datos");
        btnCargarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarDatosActionPerformed(evt);
            }
        });
        getContentPane().add(btnCargarDatos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, -1, 40));

        btnguardarJson.setBackground(new java.awt.Color(153, 255, 102));
        btnguardarJson.setForeground(new java.awt.Color(0, 0, 0));
        btnguardarJson.setText("Guardar en Archivo");
        btnguardarJson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarJsonActionPerformed(evt);
            }
        });
        getContentPane().add(btnguardarJson, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 240, -1, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_nombEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombEmpresaActionPerformed

    }//GEN-LAST:event_txt_nombEmpresaActionPerformed

    private void txtAnioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAnioActionPerformed

    }//GEN-LAST:event_txtAnioActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed

    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSalarioActionPerformed

    private void btnGuardarEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarEActionPerformed

        if (!txt_nombEmpresa.getText().isEmpty())
        {
            ControllerE = new Controlador(txt_nombEmpresa.getText(), Integer.parseInt(cantEmpleados.getValue().toString()));
            llenarT();
            JOptionPane.showMessageDialog(null, "Datos Agregados");
        } else
        {
            JOptionPane.showMessageDialog(null, "DATOS INCOMPLETOS \n Ingrese el nombre de su empresa");
        }
    }//GEN-LAST:event_btnGuardarEActionPerformed

    private void btnGuardarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarEmpleadoActionPerformed
        try
        {

            guardarEmpleado();
        } catch (Llena expt)
        {
            JOptionPane.showMessageDialog(null, "LA TABLA YA ESTA LLENA");
            System.out.println(expt);
        }
    }//GEN-LAST:event_btnGuardarEmpleadoActionPerformed

    private void btnCargarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarDatosActionPerformed
        CargarArchivo();
    }//GEN-LAST:event_btnCargarDatosActionPerformed

    private void btnguardarJsonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarJsonActionPerformed
        try
        {
            Controlador_Guardar.guardar_Archivo(ControllerE);
        } catch (FileNotFoundException ex)
        {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnguardarJsonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaDatos;
    private javax.swing.JButton btnCargarDatos;
    private javax.swing.JButton btnGuardarE;
    private javax.swing.JButton btnGuardarEmpleado;
    private javax.swing.JButton btnguardarJson;
    private javax.swing.JSpinner cantEmpleados;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtAnio;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtDia;
    private javax.swing.JTextField txtMes;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtSalario;
    private javax.swing.JTextField txt_nombEmpresa;
    // End of variables declaration//GEN-END:variables
}
