package Controlador;

import Modelo.Empresa;
import Modelo.Empleado;

/**
 * @author Jaime Mendoza
 */
public class Controlador {

    private Empresa empresa;

    public Controlador() {
    }

    public Controlador(String nombre, Integer tamanio) {
        getEmpresa().setNombre(nombre);
        getEmpresa().setArregloEmpleado(new Empleado[tamanio]);
    }

    public Empresa getEmpresa() {
        if (empresa == null)
        {
            empresa = new Empresa();
        }
        return this.empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public void imprimir() {
        System.out.println(getEmpresa().getNombre());
        for (int i = 0; i < getEmpresa().getArregloEmpleado().length; i++)
        {
            System.out.println(getEmpresa().getArregloEmpleado()[i]);
        }
    }

}
