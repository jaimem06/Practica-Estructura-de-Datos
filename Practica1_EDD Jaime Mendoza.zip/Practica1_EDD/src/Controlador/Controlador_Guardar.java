package Controlador;

import Controlador.Controlador;
import Modelo.Categoria;
import Modelo.Empleado;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Calendar;

/**
 * @author Jaime Mendoza
 */
public class Controlador_Guardar {

    public static int CalcularTiempoTrabajando(Calendar IngresoE) {
        int aniosEmpleo;
        Calendar calendario = Calendar.getInstance();

        aniosEmpleo = calendario.get(Calendar.YEAR) - IngresoE.get(Calendar.YEAR);

        return aniosEmpleo;
    }
    
        public static Controlador Leer_Datos() throws IOException {
        Controlador ControllerE = new Controlador();
        Reader leer_Archivo = Files.newBufferedReader(Paths.get("Datos.json"));
        Gson gson = new Gson();
        ControllerE = (gson.fromJson(leer_Archivo, Controlador.class));
        return ControllerE;
    }
    
    public static Float CalcularSalario(Empleado t1){
        return t1.getSueldo()+ (t1.getSueldo() * t1.getBono());
    }

    public static Categoria Asignar_Categoria(Empleado empleado) {
        if (empleado.getTiempoEmpl() <= 5)
        {
            return Categoria.Junior;
        } else if (empleado.getTiempoEmpl() <= 15)
        {
            return Categoria.Senior;
        } else
        {
            return Categoria.Veterano;
        }
    }
   
    public static void guardar_Archivo(Controlador ControllerE) throws FileNotFoundException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String json = gson.toJson(ControllerE);
        try
        {
            PrintWriter Escribir_Archivo = new PrintWriter(new File("Datos.json"));
            Escribir_Archivo.write(json);
            Escribir_Archivo.flush();
            Escribir_Archivo.close();
            System.out.println("Guardado Correctamente");
        } catch (Exception e)
        {
            System.out.println("Error al Guardar");
            System.out.println(e);
        }
    }
     public static Float Asignar_Bonificacion(Categoria categoria) {

        switch (categoria)
        {
            case Junior:
                return 0f; case Senior: return 0.1f; case Veterano: return 0.2f; default: return 0f;
        }
    }

}
 